﻿using System;
namespace ProgramOne;
class Program{
    public static void Main(string[] args)
    {
        // create a object for EmployeeInfo
        EmployeeInfo employeeInfo=new EmployeeInfo("sivakumar123");
        employeeInfo.KeyInfo; // Only assignment, call, increment, decrement, await, and new object expressions can be used as a statement
    }
}